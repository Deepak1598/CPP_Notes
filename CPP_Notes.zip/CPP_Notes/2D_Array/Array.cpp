#include<iostream>
using namespace std;

int main()
{
    int m,n;
    cout<<"enter the number of Row in a array"<<endl;
    cin>>m;
    cout<<"enter the number of col in a array"<<endl;
    cin>>n;
    int val;
    int arr [m][n];

    for(int i=0;i<m;i++)
    {
        for(int j=0;j<n;j++)
        {
            cout<<"Enter the value"<<"Row "<<i<<" :"<<endl;
            cin>>val;
            arr [i][j]=val;
        }
    }

    for(int i=0;i<m;i++)
    {
        for(int j=0;j<n;j++)
        {
            cout<<arr [i][j]<<" ";
        }
        cout<<endl;
    }

    int target;
    int count=0;
    cout<<"Enter the target number "<<endl;
    cin>>target;
    for(int i=0;i<m;i++)
    {
        for(int j=0;j<m;j++)
        {
            if(arr[i][j]==target)
            {
                count++;
            }
        }
    }
    if(count==1)
    {
        cout<<"Number is present"<<endl;
    }
    else
    {
        cout<<"Number is NOT present"<<endl;
    }
    
    for(int i=0;i<m;i++)
    {
        int sum=0;
        for(int j=0;j<m;j++)
        {
          sum=sum+arr[i][j];  
        }
        cout<<i<<"th row sum is :"<<sum<<endl;
    }

    return 0;
}