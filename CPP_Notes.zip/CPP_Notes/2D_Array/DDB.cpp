#include<iostream>
using namespace std;

void fun3()
{
    int fun3Variable = 40;

    cout<<"Fun3 Variable: "<<fun3Variable<<endl;
}


void fun2()
{
    int fun2Variable = 30;

    cout<<"Fun2 Variable: "<<fun2Variable<<endl;

    fun3();
}

void fun1()
{
    int fun1Variable = 20;

    cout<<"Fun1 Variable: "<<fun1Variable<<endl;

    fun2();
}

int main()
{ 
    int mainVareiable =10;

    cout<<"Main Variable: "<<mainVareiable<<endl;

    fun1();


    return 0;
}
