#include<iostream>
using namespace std;

int main()
{
    int m,n;
    cout<<"enter the number of Row in a array"<<endl;
    cin>>m;
    cout<<"enter the number of col in a array"<<endl;
    cin>>n;
    int val;
    int arr [m][n];

    for(int i=0;i<m;i++)
    {
        for(int j=0;j<n;j++)
        {
            cout<<"Enter the value"<<"Row "<<i<<" :"<<endl;
            cin>>val;
            arr [i][j]=val;
        }
    }

    for(int i=0;i<m;i++)
    {
        for(int j=0;j<n;j++)
        {
            cout<<arr [i][j]<<" ";
        }
        cout<<endl;
    }

//==================================spiral print=======================================//
int startingRow=0;
int endingRow=m-1;
int startingcol=0;
int endingcol=n-1;

int count=0;
int total=m*n;

while(count<total)
{
    //print first row
    for(int i=startingcol;i<=endingcol;i++)
    {
        cout<<arr[startingRow][i]<<" ";
        count++;
    }
    startingRow++;
    //print last col
    for(int i=startingRow;i<=endingRow;i++)
    {
        cout<<arr[i][endingcol]<<" ";
        count++;
    }
    endingcol--;
    //print last row
    for(int i=endingcol;i>=startingcol;i--)
    {
        cout<<arr[endingRow][i]<<" ";
        count++;
    }
    endingRow--;
    //print first col
    for(int i=endingRow;i>=startingRow;i--)
    {
        cout<<arr[i][startingcol]<<" ";
        count++;
    }
    startingcol++;

}

return 0;
}