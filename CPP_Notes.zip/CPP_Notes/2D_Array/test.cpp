#include<iostream>
#include<map>
#include <memory>
using namespace std;


int main()
{
    [](){
        cout<<"hello world"<<endl;
    }();
    string str="deepak yadav";

    unique_ptr<int> ptr = make_unique<int>(10);
    cout << *ptr << endl;

    auto t1 = move(ptr);
    cout << *t1 << endl;
    cout <<"helo world"<<endl;
    shared_ptr<int> sptr1 = make_shared<int>(20);
    cout << *sptr1 << endl;
    shared_ptr<int> sptr2 = sptr1; // Shared ownership
    *sptr1 = 500; // Modifying the value through sptr1
    cout << *sptr2 << endl;
    cout << "Use count: " << sptr1.use_count() << endl; // Output: 2
    cout << "Use count: " << sptr2.use_count() << endl; // Output: 2    
    cout << "ptr1 value: " << *sptr1 << ", ptr2 value: " << *sptr2 << endl;
    cout << "ptr1: " << sptr1 << ", ptr2: " << sptr2 << endl;
    cout << "Use count after resetting sptr1: " << sptr1.use_count() << endl; // Output: 1
    cout << "Use count after resetting sptr2: " << sptr2.use_count() << endl; // Output: 1
    sptr1.reset(); // Release ownership of the resource 
    cout<<"after reset 1:"<< sptr1<<endl;
    cout<<"after reset 2:"<< sptr2<<endl;
    cout << "Use count after resetting sptr1: " << sptr1.use_count() << endl; // Output: 0
    cout << "Use count after resetting sptr2: " << sptr2.use_count() << endl; // Output: 0
    sptr2.reset(); // Release ownership of the resource
    cout << "Use count after resetting sptr1: " << sptr1.use_count() << endl; // Output: 0
    cout << "Use count after resetting sptr2: " << sptr2.use_count() << endl; // Output: 0
    cout <<"sptr1 address: " << sptr1.get() << endl;
    cout << "sptr2 address: " << sptr2.get() << endl;
    // int n=str.size();
    
    // map<char,int>m;
    
    // for(int i=0;i<n;i++)
    // {
    //     if(str[i]!=' ')
    //         m[str[i]]++;
    // }
    
    // for(auto i:m)
    // {
    //     cout<<i.first<<"  "<<i.second<<endl;
    // }
    
    return 0;
}