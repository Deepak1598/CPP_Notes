#include<iostream>
using namespace std;

int main()
{
    int m,n;
    cout<<"enter the number of Row in a array"<<endl;
    cin>>m;
    cout<<"enter the number of col in a array"<<endl;
    cin>>n;
    int val;
    int arr [m][n];

    for(int i=0;i<m;i++)
    {
        for(int j=0;j<n;j++)
        {
            cout<<"Enter the value"<<"Row "<<i<<" :"<<endl;
            cin>>val;
            arr [i][j]=val;
        }
    }

    for(int i=0;i<m;i++)
    {
        for(int j=0;j<n;j++)
        {
            cout<<arr [i][j]<<" ";
        }
        cout<<endl;
    }
//=================top to bottom and bottom to top======================//

    for(int j=0;j<n;j++)
    {
        if(j&1)
        {
            for(int i=n-1;i>=0;i--)//bottom to top
            {
                cout<<arr[i][j]<<" ";
            }
        }
        else
        {
             for(int i=0;i<n;i++)//top to bottom
            {
                cout<<arr[i][j]<<" ";
            }
        }
    }

return 0;
}