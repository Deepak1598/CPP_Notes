#include<iostream>
using namespace std;

void minElement(int arr[],int n)
{
    int min=arr[0];
    for(int i=1;i<n;i++)
    {
        if(min>arr[i])
        {
            min=arr[i];
        }
    }
    cout<<"Min value:"<<min;
}
void maxElement(int arr[],int n)
{
    int max=arr[0];
    for(int i=1;i<n;i++)
    {
        if(max<arr[i])
        {
            max=arr[i];
        }
    }
    cout<<"Max value:"<<max;
}

int main()
{
    int arr[]={4,6,1,5,3};
    int n=sizeof(arr)/sizeof(arr[0]);
    minElement(arr,n);
    cout<<endl;
    maxElement(arr,n);

    return 0;
}
