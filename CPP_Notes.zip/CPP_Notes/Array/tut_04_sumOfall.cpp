#include<iostream>
using namespace std;

void sumofall(int arr[],int n)
{
    int sum=0;

    for(int i=0;i<n;i++)
    {
        sum=sum+arr[i];
    }
    cout<<"sum of all element is :"<<sum;
}

int main()
{
    int arr[]={2,3,4,5,6};

    int n=sizeof(arr)/sizeof(arr[0]);

    sumofall(arr,n);

    return 0;
}
