#include<iostream>
using namespace std;

void revers(int arr[],int n)
{
    int e=n-1;
    int s=0;

    while(s<e)
    {
        swap(arr[s],arr[e]);
        s++;
        e--;
    }
    cout<<"revers the array :";
    for(int i=0; i<n ; i++)
    {
        cout<<arr[i]<<" ";
    }
}


int main()
{
    int arr[]={7,8,9,10,11};

    int n=sizeof(arr)/sizeof(arr[0]);

    revers(arr,n);

    return 0;
}