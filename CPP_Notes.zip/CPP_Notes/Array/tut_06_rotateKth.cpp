#include <iostream>
using namespace std;

void rotateKth(int arr[], int n, int k)
{
    k = k % n;

    int temp[k];

    // Store first k elements
    for(int i = 0; i < k; i++)
    {
        temp[i] = arr[i];
    }

    // Shift remaining elements left
    for(int i = 0; i < n - k; i++)
    {
        arr[i] = arr[i + k];
    }

    // Copy temp elements at end
    for(int i = n - k, j = 0; i < n; i++, j++)
    {
        arr[i] = temp[j];
    }

    cout << "Rotated Array: ";

    for(int i = 0; i < n; i++)
    {
        cout << arr[i] << " ";
    }
}

int main()
{
    int arr[] = {7, 8, 9, 10, 11};

    int n = sizeof(arr) / sizeof(arr[0]);

    int k = 2;

    rotateKth(arr, n, k);

    return 0;
}