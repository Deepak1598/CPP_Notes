#include<iostream>
using namespace std;
void sortArray(int arr[],int n)
{
    for(int i=0;i<n;i++)
    {
        for(int j=i+1;j<n;j++)
        {
            if(arr[i]>arr[j])
            {
                swap(arr[i],arr[j]);
            }
        }
    }
    for(int i=0; i<n ; i++)
    {
        cout<<arr[i]<<" ";
    }
}

int main()
{
    int arr[]={4,3,6,7,9,2};

    int n=sizeof(arr)/sizeof(arr[0]);
    sortArray(arr,n);
    return 0;
}