#include<iostream>
#include<algorithm>
using namespace std;

void frequency(int arr[],int n)
{
    
    sort(arr,arr+n);
    for(int i=0;i<n;i++)
    {
        int count=1;
        while ((i<n-1)&&(arr[i]==arr[i+1]))
        {
            count++;
            i++;
        }
            cout<<arr[i]<<" : "<<count<<endl;
    }
}

int main()
{
    int arr[]={3,2,3,2,4,4,4,5};

    int n=sizeof(arr)/sizeof(arr[0]);

    frequency(arr,n);

    return 0;
}