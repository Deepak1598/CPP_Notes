#include<iostream>
#include<algorithm>
using namespace std;

void duplicate(int arr[],int n)
{
    sort(arr,arr+n);

    cout<<"remove the all duplicate number :"<<endl;
    //2,3,3,4,5

    for(int i=0;i<n;i++)
    {
        if(arr[i]!=arr[i+1])
        {
            cout<<arr[i]<<" ";
        }
    }
}

int main()
{
    int arr[]={5,4,3,2,3};

    int n=sizeof(arr)/sizeof(arr[0]);

    duplicate(arr,n);

    return 0;
}