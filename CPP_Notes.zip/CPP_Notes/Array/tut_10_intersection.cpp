#include<iostream>
using namespace std;

void intersection(int arr1[],int m,int arr2[],int n)
{
    for(int i=0;i<m;i++)
    {
        for(int j=0;j<n;j++)
        {
            if(arr1[i]==arr2[j])
            {
                cout<<arr1[i]<<" ";
            }
        }
    }
}

int main()
{
    int arr1[]={1,2,3,4,5};

    int arr2[]={3,5,4};

    int m=sizeof(arr1)/sizeof(arr1[0]);
    int n=sizeof(arr2)/sizeof(arr2[0]);

    intersection(arr1,m,arr2,n);

    return 0;
}

/*
#include <iostream>
#include <unordered_set>
#include <vector>

using namespace std;

vector<int> findDuplicates(const vector<int>& a, const vector<int>& b) {
    unordered_set<int> setA(a.begin(), a.end()); // Insert all elements of 'a' into setA
    unordered_set<int> duplicates; // To store duplicates without repetition

    // Check for duplicates in collection 'b'
    for (int num : b) {
        if (setA.find(num) != setA.end()) {
            duplicates.insert(num);
        }
    }

    // Convert the set to a vector
    return vector<int>(duplicates.begin(), duplicates.end());
}

int main() {
    // Example collections 'a' and 'b'
    vector<int> a = {1, 4, 45, 13, 67};
    vector<int> b = {2, 1, 14, 435, 313, 67, 98, 0};

    // Find duplicate numbers between the two collections
    vector<int> duplicateNumbers = findDuplicates(a, b);

    // Print the duplicate numbers
    if (duplicateNumbers.empty()) {
        cout << "No duplicate numbers found." << endl;
    } else {
        cout << "Duplicate numbers found: ";
        for (int num : duplicateNumbers) {
            cout << num << " ";
        }
        cout << endl;
    }

    return 0;
}



*/