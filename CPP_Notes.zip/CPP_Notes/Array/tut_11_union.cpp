#include<iostream>
#include<set>
using namespace std;

void unionELM(int arr1[],int m,int arr2[],int n)
{
    set<int> s;
    for(int i=0;i<m;i++)
    {
        s.insert(arr1[i]);
    }

    for(int i=0;i<n;i++)
    {
        s.insert(arr2[i]);
    }

    set<int> :: iterator it;
    for(it=s.begin();it!=s.end();it++)
    {
        cout<<*it<<" ";
    }
}

int main()
{
    int arr1[]={1,2,3,3,4,5};
    int arr2[]={3,3,5,4,9,8};

    int m=sizeof(arr1)/sizeof(arr1[0]);
    int n=sizeof(arr2)/sizeof(arr2[0]);

    unionELM(arr1,m,arr2,n);

    return 0;
}