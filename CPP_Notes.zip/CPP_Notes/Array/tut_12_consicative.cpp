#include<iostream>
using namespace std;
void missELM(int arr[],int n)
{
    for(int i=0;i<n;i++)
    {
        if((arr[i]+1)!=arr[i+1])
        {
            cout<<"missing element : "<<arr[i]+1;
            break;
        }
    }
}

int main()
{
    //int arr[] = {1, 2, 4, 5, 6, 7, 8, 9};
    int arr[] = {-4, -3, -1, 0, 1, 2};

    int n=sizeof(arr)/sizeof(arr[0]);

    missELM(arr,n);

    return 0;
}