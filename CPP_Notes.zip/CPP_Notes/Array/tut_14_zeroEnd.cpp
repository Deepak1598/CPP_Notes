#include<iostream>
using namespace std;

void printArray(int arr[],int n)
{
    for(int i=0;i<n;i++)
    {
        cout<<arr[i]<<" ";
    }
}

void zeroEnd(int arr[], int n) {
    int count = 0; // Count of non-zero elements

    for (int i = 0; i < n; i++) {
        if (arr[i] != 0) {
            arr[count++] = arr[i];
        }
    }

    while (count < n) 
    {
        arr[count++] = 0;
    }
}
int main()
{
    int arr[]={1,9,8,4,0,0,2,7,0,6,0,9};

    int n=sizeof(arr)/sizeof(arr[0]);

    zeroEnd(arr,n);

    printArray(arr,n);

    return 0;
}