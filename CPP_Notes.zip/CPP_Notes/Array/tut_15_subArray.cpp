#include<iostream>
using namespace std;

void subArraySum(int arr[],int n,int sum)
{
    for(int i=0;i<n;i++)
    {
        int sumArr=arr[i];
        if(sumArr==sum)
        {
            cout<<"sub array is : "<<i<<endl;
            return;
        }
        else
        {
            for(int j=i+1;j<n;j++)
            {
                sumArr=sumArr+arr[j];
                cout<<sumArr<<" ";

                if(sumArr==sum)
                {
                    cout<<"sub array is : "<<i <<" , "<<j<<endl;
                    return;
                }
            }
        }
    }
}

int main()
{
    int arr[] = { 15, 2, 4, 8, 9, 5, 10, 23 };
    int n = sizeof(arr) / sizeof(arr[0]);
    int sum = 23;
    subArraySum(arr, n, sum);
    return 0;
}