#include<iostream>
using namespace std;

void productMax(int arr[],int n)
{
    int max=1;
    for(int i=0;i<n;i++)
    {
        for(int j=i+1;j<n;j++)
        {
            if(max<(arr[i]*arr[j]))
            {
                max=arr[i]*arr[j];
            }
        }
    }
    cout<<"product Max value is : "<<max;
}

int main()
{
    int arr[]={1,9,2,3,4,5};

    int n=sizeof(arr)/sizeof(arr[0]);

    productMax(arr,n);

    return 0;
}