#include<iostream>
using namespace std;

void LeadrELM(int arr[],int n)
{
    cout<<"leader element is : ";
    for(int i=0;i<n;i++)
    {
        int j;
        for(j=i+1;j<n;j++)
        {
            if(arr[i]<=arr[j])
            {   
                break;
            }
           
        }
         if(j==n)
        {
            cout<<arr[i]<<" ";
        }
    }
    //cout<<"product Max value is : "<<max;
}

int main()
{
    int arr[]={16, 17, 4, 3, 5, 2};

    int n=sizeof(arr)/sizeof(arr[0]);

    LeadrELM(arr,n);

    return 0;
}