#include<iostream>
using namespace std;

void equilibrium(int arr[],int n)
{
    for(int i=1;i<n;i++)
    {
        int leftSum=0;
        for(int j=0;j<i;j++)
        {
            leftSum+=arr[j];
        }
        int rightSum=0;
        for(int j=i+1;j<n;j++)
        {
            rightSum+=arr[j];
        }

        if(leftSum==rightSum)
        {
            cout<<"equlibrium Index is : "<<i;
            //break;
        }
    }
    //cout<<"not found !!";
}

int main()
{
    int arr[] = { -7, 1, 5, 2, -4, 3, 0 };
    int n = sizeof(arr) / sizeof(arr[0]);
    equilibrium(arr, n);
    return 0;
}