#include<iostream>
using namespace std;
void ELM(int arr[],int n)
{
    int low=0;
    int hig=n-1;
    int mid=0;

    while(mid<=hig)
    {
        switch (arr[mid])
        {
        case 0:
            swap(arr[low++],arr[mid++]);
            break;

        case 1:
            mid++;
            break;

        case 2:
            swap(arr[mid],arr[hig--]);
            break;        
        }
    }
}
void printArray(int arr[],int n)
{
    for(int i=0;i<n;i++)
    {
        cout<<arr[i]<<" ";
    }
}
int main()
{
    int arr[] = { 1,0,1,2,1,2,1,0 };
    int n = sizeof(arr) / sizeof(arr[0]);
    ELM(arr, n);
    printArray(arr,n);
    return 0;
}