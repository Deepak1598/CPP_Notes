#include <iostream>
#include <cstring>
using namespace std;

class Student
{
public:
    char* name;

    Student(const char* n)
    {
        name = new char[strlen(n) + 1];
        strcpy(name, n);
    }

    // Copy Constructor
    Student(const Student& o)
    {
        name = new char[strlen(o.name) + 1];
        strcpy(name, o.name);
    }

    // Copy Assignment Operator
    Student& operator=(const Student& o)
    {
        if (this == &o)   // Self-assignment check
            return *this;

        delete[] name;    // Free old memory

        name = new char[strlen(o.name) + 1];
        strcpy(name, o.name);

        return *this;
    }

    ~Student()
    {
        delete[] name;
    }
};

int main()
{
    Student obj1("Deepak");
    Student obj2("Rahul");

    obj2 = obj1;     // Copy Assignment Operator Call

    obj2.name[0] = 'K';

    cout << obj1.name << endl;
    cout << obj2.name << endl;

    return 0;
}