#include <iostream>
using namespace std;

class Node
{
public:
    int data;
    Node* next;

    Node(int d)
    {
        data = d;
        next = NULL;
    }
};

// Print Linked List
void printList(Node* head)
{
    while(head != NULL)
    {
        cout << head->data << " -> ";
        head = head->next;
    }
    cout << "NULL" << endl;
}

// Merge Two Sorted Linked Lists
Node* mergeSortedLists(Node* head1, Node* head2)
{
    // Dummy node
    Node dummy(0);

    // Tail points to dummy initially
    Node* tail = &dummy;

    while(head1 != NULL && head2 != NULL)
    {
        if(head1->data <= head2->data)
        {
            tail->next = head1;     // attach node from list1
            head1 = head1->next;    // move list1
        }
        else
        {
            tail->next = head2;     // attach node from list2
            head2 = head2->next;    // move list2
        }

        tail = tail->next;          // move tail
    }

    // Attach remaining nodes
    if(head1 != NULL)
        tail->next = head1;

    if(head2 != NULL)
        tail->next = head2;

    return dummy.next;
}

int main()
{
    // First Sorted List
    Node* head1 = new Node(1);
    head1->next = new Node(3);
    head1->next->next = new Node(5);

    // Second Sorted List
    Node* head2 = new Node(2);
    head2->next = new Node(4);
    head2->next->next = new Node(6);

    cout << "List 1: ";
    printList(head1);

    cout << "List 2: ";
    printList(head2);

    Node* mergedHead = mergeSortedLists(head1, head2);

    cout << "\nMerged List: ";
    printList(mergedHead);

    return 0;
}