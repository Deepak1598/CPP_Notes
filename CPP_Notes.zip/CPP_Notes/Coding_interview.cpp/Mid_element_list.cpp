#include<iostream>
using namespace std;

class Node 
{
    public:
        int data;
        Node* next;
        
        Node(int d)
        {
            data=d;
            next=NULL;
        }
};

void print(Node* head)
{
    while(head!=NULL)
    {
        cout<<head->data<<"->";
        head=head->next;
    }
    cout<<endl;
}

Node* mid_node(Node* head)
{
    Node* slow=head;
    Node* fast=head;
    
    while((fast!=NULL) && (fast->next!=NULL))
    {
        slow=slow->next;
        fast=fast->next->next;
    }
    return slow;
    
    
}



int main()
{
   Node* head= new Node(10);
   head->next=new Node(20);
   head->next->next=new Node(30);
   //head->next->next->next=new Node(40);
   
   print(head);
   
   Node* mid=mid_node(head);
   
   cout<<"mid node is :"<<mid->data<<endl;
    
    
    return 0;
}