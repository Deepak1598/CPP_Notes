#include <iostream>
#include <cstring>
using namespace std;

class Student
{
public:
    char* name;

    // Constructor
    Student(const char* n)
    {
        cout << "Constructor Called" << endl;

        name = new char[strlen(n) + 1];
        strcpy(name, n);
    }

    // Copy Constructor
    Student(const Student& o)
    {
        cout << "Copy Constructor Called" << endl;

        name = new char[strlen(o.name) + 1];
        strcpy(name, o.name);
    }

    // Copy Assignment Operator
    Student& operator=(const Student& o)
    {
        cout << "Copy Assignment Operator Called" << endl;

        if (this == &o)
            return *this;

        delete[] name;

        name = new char[strlen(o.name) + 1];
        strcpy(name, o.name);

        return *this;
    }

    // Move Constructor
    Student(Student&& o)
    {
        cout << "Move Constructor Called" << endl;

        // Resource transfer
        name = o.name;

        // Source object ko empty kar diya
        o.name = nullptr;
    }

    // Move Assignment Operator
    Student& operator=(Student&& o)
    {
        cout << "Move Assignment Operator Called" << endl;

        if (this == &o)
            return *this;

        // Purani memory free
        delete[] name;

        // Ownership transfer
        name = o.name;

        // Source object ko empty kar diya
        o.name = nullptr;

        return *this;
    }

    void print()
    {
        if (name)
            cout << name << endl;
        else
            cout << "NULL" << endl;
    }

    ~Student()
    {
        cout << "Destructor Called" << endl;

        delete[] name;
    }
};

int main()
{
    Student obj1("Deepak");

    // Copy Constructor
    Student obj2 = obj1;

    // Copy Assignment Operator
    Student obj3("Rahul");
    obj3 = obj1;

    // Move Constructor
    Student obj4 = std::move(obj1);

    // Move Assignment Operator
    Student obj5("Amit");
    obj5 = std::move(obj2);

    cout << "\nobj3 : ";
    obj3.print();

    cout << "obj4 : ";
    obj4.print();

    cout << "obj5 : ";
    obj5.print();

    return 0;
}