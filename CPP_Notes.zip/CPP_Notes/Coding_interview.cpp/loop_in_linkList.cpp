#include<iostream>
using namespace std;

class Node 
{
    public:
        int data;
        Node* next;
        
        Node(int d)
        {
            data=d;
            next=NULL;
        }
};

void print(Node* head)
{
    while(head!=NULL)
    {
        cout<<head->data<<"->";
        head=head->next;
    }
    cout<<endl;
}

bool loop_in_linklist(Node* head)
{
    Node* slow=head;
    Node* fast=head;
    
    while((fast!=NULL) && (fast->next!=NULL))
    {
        slow=slow->next;
        fast=fast->next->next;
        
        if(slow==fast)
        {
            return true;
        }
    }
    return false;
    
    
}



int main()
{
   Node* head= new Node(10);
   head->next=new Node(20);
   head->next->next=new Node(30);
   head->next->next->next=new Node(40);
   head->next->next->next->next=head->next;
   
   
   //print(head);
   
   //Node* mid=mid_node(head);
   
   //cout<<"mid node is :"<<mid->data<<endl;
   
   if(loop_in_linklist)
   {
       cout<<"YES";
   }
   else
   {
       cout<<"NO";
   }
    
    
    return 0;
}