#include <iostream>
using namespace std;

class Node {
public:
    int data;
    Node* next;

    Node(int d) {
        data = d;
        next = NULL;
    }
};

// Print Linked List
void printList(Node* head) {
    while(head != NULL) {
        cout << head->data << " -> ";
        head = head->next;
    }
    cout << "NULL" << endl;
}

// Detect Cycle
bool detectCycle(Node* head) {
    Node* slow = head;
    Node* fast = head;

    while(fast != NULL && fast->next != NULL) {
        slow = slow->next;
        fast = fast->next->next;

        if(slow == fast) {
            return true;
        }
    }
    return false;
}

// Remove Cycle
void removeCycle(Node* head) {

    if(head == NULL)
        return;

    Node* slow = head;
    Node* fast = head;

    bool cycleFound = false;

    // Step 1: Detect Cycle
    while(fast != NULL && fast->next != NULL) {
        slow = slow->next;
        fast = fast->next->next;

        if(slow == fast) {
            cycleFound = true;
            break;
        }
    }

    if(!cycleFound) {
        return;
    }

    // Step 2: Find Starting Node of Cycle
    slow = head;

    while(slow != fast) {
        slow = slow->next;
        fast = fast->next;
    }

    Node* startLoop = slow;

    // Step 3: Find Last Node of Cycle
    Node* temp = startLoop;

    while(temp->next != startLoop) {
        temp = temp->next;
    }

    // Step 4: Remove Cycle
    temp->next = NULL;
}

int main() {

    Node* head = new Node(10);
    head->next = new Node(20);
    head->next->next = new Node(30);
    head->next->next->next = new Node(40);
    head->next->next->next->next = new Node(50);

    // Create Cycle
    // 50 -> 30
    head->next->next->next->next->next = head->next->next;

    if(detectCycle(head))
        cout << "Cycle Detected" << endl;
    else
        cout << "No Cycle" << endl;

    removeCycle(head);

    if(detectCycle(head))
        cout << "Cycle Detected" << endl;
    else
        cout << "Cycle Removed Successfully" << endl;

    cout << "\nLinked List After Removing Cycle:\n";
    printList(head);

    return 0;
}