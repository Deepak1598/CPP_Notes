#include <iostream>
#include <cstring>
using namespace std;

class Student
{
public:
    char* name;

    Student(const char* n)
    {
        name = new char[strlen(n) + 1];
        strcpy(name, n);
    }

    ~Student()
    {
        delete[] name;
    }
};

int main()
{
    Student s1("Deepak");

    Student s2 = s1;     // Shallow Copy

    s2.name[0] = 'K';

    cout << s1.name << endl;
    cout << s2.name << endl;
}