#include <iostream>
#include <memory>
using namespace std;

class B;

class A
{
public:
    shared_ptr<B> ptrB;

    ~A()
    {
        cout << "A Destructor Called" << endl;
    }
};

class B
{
public:
    weak_ptr<A> ptrA;   // weak_ptr does not increase ref count

    ~B()
    {
        cout << "B Destructor Called" << endl;
    }
};

int main()
{
    shared_ptr<A> a = make_shared<A>();
    shared_ptr<B> b = make_shared<B>();

    // A owns B
    a->ptrB = b;

    // B only observes A
    b->ptrA = a;

    cout << "A Count : " << a.use_count() << endl;
    cout << "B Count : " << b.use_count() << endl;

    // Access weak_ptr safely
    if(auto temp = b->ptrA.lock())
    {
        cout << "A object is alive" << endl;
    }

    return 0;
}