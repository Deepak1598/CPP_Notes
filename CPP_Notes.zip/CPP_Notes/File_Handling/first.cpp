#include<iostream>
#include<fstream>
using namespace std;

int main()
    {
        ofstream file("test.txt");

        file << "hello Deepal";

        return 0;
    }
