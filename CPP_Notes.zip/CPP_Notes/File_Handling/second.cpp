#include<iostream>
#include<fstream>
using namespace std;

int main()
{
    ifstream file("test.txt");
    string s;
    while(getline(file,s))
    {
         cout<<s<<endl;
    }
       
    file.close();
    return 0;
}