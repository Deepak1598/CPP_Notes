#include<iostream>
using namespace std;

class Node
{
    public:
     int data;
     Node* next;

     Node(int data)
     {
        this->data=data;
        this->next=NULL;
     }
};

void InsertHead(Node* &head,int data)
{
    Node* temp=new Node(data);
    temp->next=head;
    head=temp;
}

Node* floydDetection(Node* head)
{
    if(head==NULL)
    {
        cout<<"list is empty";
        return NULL;
    }
    
    Node* slow=head;
    Node* fast=head;
    while(slow!=NULL && fast!=NULL)
    {
        fast=fast->next;
        if(fast!=NULL)
        {
            fast=fast->next;
        }
        slow=slow->next;
        
        if(slow==fast)
        {
            return slow;
        }
    }
    return NULL;
}

Node* getStarting(Node* head)
{
    if(head==NULL)
    {
        cout<<"list is empty";
        return NULL;
    }
    
    Node* intersection=floydDetection(head);
    Node* slow=head;
    
    if(slow!=intersection)
    {
        slow=slow->next;
        intersection=intersection->next;
    }
    
    return slow;
}

void removeloop(Node* head)
{
    if(head==NULL)
    {
        cout<<"list is empty";
        return;
    }
    
    Node* firstN=getStarting(head);
    
    Node* temp=firstN;
    while(temp->next!=firstN)
    {
        temp=temp->next;
        
    }
    temp->next=NULL;
}



void print(Node* head)
{
    if(head==NULL)
    {
        cout<<"list is empty"<<endl;
        return;
    }
    Node* temp=head;

    while(temp!=NULL)
    {
        cout<<temp->data<<" ";
        temp=temp->next;
    }

   // return 0;
}

int main()
{
    Node* node1=new Node(10);

    Node* head=node1;
    Node* tail=node1;

    InsertHead(head,20);
    InsertHead(head,30);
    InsertHead(head,40);
    InsertHead(head,50);

   print(head);
   cout<<endl;
   

    tail->next=head->next;
     //print(head);
     if(floydDetection(head)!=NULL)
     {
         cout<<"present";
     }
     else
     {
         cout<<"NOT present";
     }
     cout<<endl;
     
     Node* get=getStarting(head);
     
     cout<<get->data;
     
     cout<<endl;
     
     removeloop(head);
     print(head);
    return 0;
}