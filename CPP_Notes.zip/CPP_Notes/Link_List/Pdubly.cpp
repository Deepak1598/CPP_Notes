#include<iostream>
using namespace std;

class Node{
    public:
    int data;
    Node* prev;
    Node* next;

    Node(int data)
    {
        this->data=data;
        this->next=NULL;
        this->prev=NULL;
    }

};

void inserthead(Node* &head,Node* &tail,int data)
{
    if(head==NULL)
    {
        Node* temp=new Node(data);
        tail=temp;
        head=temp;
    }
    else{
        Node* temp=new Node(data);
        temp->next=head;
        head->prev=temp;
        head=temp;

    }
}
void insertail(Node* &head,Node* &tail,int data)
{
    if(head==NULL)
    {
        Node* temp=new Node(data);
        tail=temp;
        head=temp;
    }
    else{
        Node* temp=new Node(data);
        tail->next=temp;
        temp->prev=tail;
        tail=temp;
    }

}
void insertAT(Node* &head,Node* &tail,int data,int pos)
{
    if(pos==1)
    {
        inserthead(head,tail,data);
        return;
    }

    int cnt=1;
    Node* temp=head;
    while(cnt<pos-1)
    {
        
        temp=temp->next;
        cnt++;
    }

    if(temp->next==NULL)
    {
        insertail(head,tail,data);
        return;
    }

    Node* insertNode =new Node(data);
    insertNode->next=temp->next;
    temp->next->prev=insertNode;
    
    temp->next=insertNode;
    insertNode->prev=temp;


}

void deletNode(Node* &head,Node* &tail,int pos)
{
    if(pos==1)
    {
        Node* temp=head;
        temp->next->prev=NULL;
        head=temp->next;
        temp->next=NULL;
        delete temp;
    }
    else{
        Node* prevI=NULL;
        Node* curr=head;

        int cnt=1;
        while(cnt>pos)
        {
            prevI=curr;
            curr=curr->next;
            cnt++;
        }

        prevI->next=curr->next;
        prevI->next->prev=prevI;
        curr->next=NULL;
        curr->prev=NULL;
        delete curr;

    }
}

void print(Node* &head)
{
    Node* temp=head;

    while(temp!=NULL)
    {
        cout<<temp->data<<" ";
        temp=temp->next;
    }
   // return 0;
}

int main()
{
    Node* head=NULL;
    Node* tail=NULL;

    inserthead(head,tail,20);
    inserthead(head,tail,30);
    inserthead(head,tail,40);
    insertail(head,tail,999);
    insertAT(head,tail,555,3);
    print(head);

    return 0;
}
