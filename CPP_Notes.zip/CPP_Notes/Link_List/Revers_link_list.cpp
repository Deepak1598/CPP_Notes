#include <iostream>
using namespace std;

class Node
{
public:
    int data;
    Node* next;

    Node(int val)
    {
        data = val;
        next = NULL;
    }
};

// Print Linked List
void printList(Node* head)
{
    while(head != NULL)
    {
        cout << head->data << " -> ";
        head = head->next;
    }
    cout << "NULL" << endl;
}

// Reverse Linked List
void reverseList(Node* &head)
{
    Node* prev = NULL;
    Node* curr = head;

    while(curr)
    {
        Node* next = curr->next; // Store next node
        curr->next = prev;       // Reverse link
        prev = curr;             // Move prev forward
        curr = next;             // Move curr forward
    }

    head = prev;
}

int main()
{
    Node* head = new Node(10);
    head->next = new Node(20);
    head->next->next = new Node(30);
    head->next->next->next = new Node(40);
    head->next->next->next->next = new Node(50);

    cout << "Original List: ";
    printList(head);

    reverseList(head);

    cout << "Reversed List: ";
    printList(head);

    return 0;
}
