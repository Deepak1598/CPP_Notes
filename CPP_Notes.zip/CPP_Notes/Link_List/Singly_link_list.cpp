#include<iostream>
using namespace std;

class Node
{
    public:
        int data;
        Node* next;
        
        Node(int data)
        {
            this->data=data;
            this->next=NULL;
        }
    
};

void print(Node* &head)
{
    Node* temp=head;
    
    while(temp!=NULL)
    {
        cout<<temp->data<<" ";
        temp=temp->next;
    }
}

void insertHead(Node* &head,int data)
{
    Node* temp=new Node(data);
    temp->next=head;
    head=temp;
}

void insertTail(Node* tail,int data)
{
    Node* temp=new Node(data);
    tail->next=temp;
    tail=temp;
    
}

void insertPos(Node* &head,Node* &tail,int data,int pos)
{
    if(pos==1)
    {
        insertHead(head,data);
        return;
    }
    
    Node* temp=head;
    int cnt=1;
    while(cnt<pos-1)
    {
        temp=temp->next;
        cnt=cnt+1;
        
    }
    
    if(temp->next==NULL)
    {
        insertTail(tail,data);
    }
    
    Node* insertNode=new Node(data);
    
    insertNode->next=temp->next;
    temp->next=insertNode;
    
    
}

void deleteNode(Node* &head,int pos)
{

    if(pos==1)
    {
       Node* temp=head;
       head=temp->next;
       temp->next=NULL;
       delete temp;
    }
    else
    {
        Node* curr=head;
        Node* prev=NULL;
        int cnt=1;
        while(cnt<pos)
        {
            prev=curr;
            curr=curr->next;
            cnt=cnt+1;
        }
        
        prev->next=curr->next;
        curr->next=NULL;
        delete curr;
        
    }
}

Node* reversNode(Node* &head)
{
    if(head==NULL || head->next==NULL)
    {
        return head;
    }
    
    Node* small = reversNode(head->next);
    
    head->next->next=head;
    
    head->next=NULL;
    
    return small ;
}

int main()
{
    Node* node1 = new Node(10);
    Node* head=node1;
    Node* tail=node1;
    
    insertHead(head,20);
    insertHead(head,30);
    
    
    
    print(head);
    cout<<endl;
    
    insertTail(tail,1111);
    
    insertPos(head,tail,9999,2);
    print(head);
    cout<<endl;
    deleteNode(head,2);
    print(head);
    
    cout<<endl;
    
    cout<<"revers Link list is: "<<endl;
    
    head=reversNode(head);
    print(head);
    
    return 0;
}