#include<iostream>
using namespace std;

class Node{

    public:
    int data;
    Node* next;

    Node(int data)
    {
        this->data=data;
        this->next=NULL;
    }

};
void insertHead(Node* &head,int data)
{
    Node* temp=new Node(data);
    temp->next=head;
    head=temp;
}

void insertTail(Node* &tail,int data)
{
    Node* temp=new Node(data);
    tail->next=temp;
    tail=temp;
}

void insertAt(Node* head,Node* tail,int data,int pos)
{
    if(pos==1)
    {
        insertHead(head,data);
        return;
    }

    Node* temp=head;
    int cnt=1;
    while(cnt<pos-1)
    {
        temp=temp->next;
        cnt++;
    }

    if(temp->next==NULL)
    {
        insertTail(tail,data);
        return;
    }

    Node* nodetoinsert=new Node(data);

    nodetoinsert->next=temp->next;
    temp->next=nodetoinsert;

}

void deletePos(Node* head,int pos)
{
    if(pos==1)
    {
        Node* temp=head;
        head=head->next;
        temp->next=NULL;
        delete temp;
    }
    else
    {
        Node* curr=head;
        Node* prev=NULL;

        int cnt=1;
        while(cnt<pos)
        {
            prev=curr;
            curr=curr->next;
            cnt++;
        }

        prev->next=curr->next;
        curr->next=NULL;
        delete curr;
    }
}

Node* reverlinklist(Node* &head)
{
    if(head==NULL || head->next==NULL)
    {
        return head;
    }

    Node* chota=reverlinklist(head->next);

    head->next->next=head;

    head->next=NULL;

    return chota;

   /* Node* prev=NULL;
   
    Node* curr=head;
    Node* forw=NULL;

    while (curr!=NULL)
    {
        forw=curr->next;
        curr->next=prev;
        prev=curr;
        curr=forw;
    }
    return prev;*/
    
}

void print(Node* &head)
{
    if(head==NULL)
    {
        cout<<"Link list is empty";
        return;
    }
    Node* temp=head;
    while(temp!=NULL)
    {
        cout<<temp->data<<" ";
        temp=temp->next;
    }
}

int main()
{
    Node* node1= new Node(10);

    Node* head=node1;
    Node* tail=node1;

    insertHead(head,20);
    insertHead(head,30);
    //insertHead(head,40);

   // insertTail(tail,100);
    //insertAt(head,tail,333,3);
    //deletePos(head,3);
    print(head);
    cout<<endl;
    head = reverlinklist(head);

    print(head);

    return 0;
}