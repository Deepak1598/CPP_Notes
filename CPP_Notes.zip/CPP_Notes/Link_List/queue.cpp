#include <iostream>
using namespace std;

class Queue {
    int* arr;
    int qfront;
    int rear;
    int size;

public:
    Queue() 
    {
        size = 100001;
        arr = new int[size];
        qfront = 0;
        rear = 0;
    }

    /*----------------- Public Functions of Queue -----------------*/

    bool isEmpty() 
    {
        return (qfront == rear);
    }

    void enqueue(int data) 
    {
        if (rear == size)
            cout << "Queue is Full" << endl;
        else 
        {
            arr[rear] = data;
            rear++;
        }
    }

    int dequeue() 
    {
        if (qfront == rear) 
        {
            cout << "Queue is Empty" << endl;
            return -1;
        } 
        else 
        {
            int ans = arr[qfront];
            arr[qfront] = -1;
            qfront++;
            if (qfront == rear) 
            {
                qfront = 0;
                rear = 0;
            }
            return ans;
        }
    }

    int front() 
    {
        if (qfront == rear) 
        {
            cout << "Queue is Empty" << endl;
            return -1;
        } 
        else 
        {
            return arr[qfront];
        }
    }
};

int main() 
{
    Queue myQueue;

    myQueue.enqueue(10);
    myQueue.enqueue(20);
    myQueue.enqueue(30);

    cout << "Front element: " << myQueue.front() << endl;

    cout << "Dequeue: " << myQueue.dequeue() << endl;

    cout << "Front element after dequeue: " << myQueue.front() << endl;

    return 0;
}
