#include<iostream>
using namespace std;

int main()
{
    cout<<"Hello CG"<<endl;

    return 0;
}