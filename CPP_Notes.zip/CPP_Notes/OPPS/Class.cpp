#include<iostream>
using namespace std;

class Emp 
{
    private:
        string name;
        int age;
        
    public:
        //Emp(){}
        Emp(string s,int a)
        {
            name=s;
            age=a;
        }
        void print()
        {
            cout<<"Name :"<<name<<endl;
            cout<<"Age :"<<age<<endl;
        }
};

int main()
{
    Emp obj("Raj",25);
    obj.print();
    return 0;
}