#include<iostream>
using namespace std;

void add(int a,int b, int c)
{
    cout<<"add of three number is :"<<(a+b+c)<<endl;
    
}
void add(int a,int b,int c,int d)
{
    cout<<"Add of four number is:"<<(a+b+c+d)<<endl;
}
void add(int a,int b)
{
    cout<<"add of two number"<<(a+b)<<endl;
}


int main()
{
   add(4,5,6);
   add(5,5);
   add(5,5,5,5); 

    return 0;
}