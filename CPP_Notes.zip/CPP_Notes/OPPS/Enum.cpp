#include<iostream>
using namespace std;
 enum week
 {
     mon,tue,wed,thu,fri,str,sun
 };
 
 int main()
 {
     enum week day;
     day=sun;
     cout<<day;
     
     return 0;
 }