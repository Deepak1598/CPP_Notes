/*
Has‑A represents a “part‑of” or “contains‑a” relationship.
One class contains another class as a member.
📌 Example in real world:

A Car has‑a Engine

In C++, this is implemented by including an object of one class inside another class.



*/


#include <iostream>
using namespace std;

class Engine {
public:
    void start() {
        cout << "Engine started" << endl;
    }
};

class Car {
private:
    Engine engine;  // Car HAS-A Engine
public:
    void drive() {
        engine.start(); // using the Engine
        cout << "Car is driving" << endl;
    }
};

int main() {
    Car c;
    c.drive();
    return 0;
}