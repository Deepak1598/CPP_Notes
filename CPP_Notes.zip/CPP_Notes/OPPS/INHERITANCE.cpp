#include<iostream>
using namespace std;


class A 
{
    private:
        int a=1;
    protected:    
        int b=2;
    public:    
        int c=3;
        
    void print()
    {
        cout<<"value of a :"<<a<<endl;
        cout<<"value of b :"<<b<<endl;
        cout<<"value of c :"<<c<<endl;
    }
};
class B : public A
{
     private:
        int m=4;
    protected:    
        int n=5;
    public:    
        int o=6;
        
    void print()
    {
        //cout<<"value of a :"<<a<<endl;
        cout<<"value of b :"<<b<<endl;
        cout<<"value of c :"<<c<<endl;
        cout<<"value of m :"<<m<<endl;
        cout<<"value of n :"<<n<<endl;
        cout<<"value of o :"<<o<<endl;
        
    }
    
};
class C : public B 
{
     private:
        int x=7;
    protected:    
        int y=8;
    public:    
        int z=9;
        
    void print()
    {
        //cout<<"value of a :"<<a<<endl;
        cout<<"value of b :"<<b<<endl;
        cout<<"value of c :"<<c<<endl;
        //cout<<"value of m :"<<m<<endl;
        cout<<"value of n :"<<n<<endl;
        cout<<"value of o :"<<o<<endl;
        cout<<"value of x :"<<x<<endl;
        cout<<"value of y :"<<y<<endl;
        cout<<"value of z :"<<z<<endl;
        
    }
    
};

int main()
{
    A obj;
    obj.print();  
    return 0;
}