#include<iostream>
using namespace std;

class Node
{
    public:
        int data;
        Node* next;
        
        Node(int data)
        {
            this->data=data;
            this->next=NULL;
        }
};
bool floydDetection(Node* head)
{
    if(head==NULL)
    {
        cout<<"list is empty";
        return false;
    }
    
    Node* slow=head;
    Node* fast=head;
    while(slow!=NULL && fast!=NULL)
    {
        fast=fast->next;
        if(fast!=NULL)
        {
            fast=fast->next;
        }
        slow=slow->next;
        
        if(slow==fast)
        {
            return true;
        }
    }
    return false;
}

void print(Node* head)
{
    if(head==NULL)
    {
        cout<<"list is empty"<<endl;
    }
    while(head!=NULL)
    {
        cout<<head->data<<" ";
        head=head->next;
    }
}
int main()
{
    Node* head=new Node(10);
    head->next=new Node(20);
    head->next->next=new Node(30);
    head->next->next->next=new Node(40);
    
    print(head);
    
    head->next->next->next->next=head->next;
    cout<<endl;
    bool hasLoop = floydDetection(head);
    
    if (hasLoop) {
        cout << "Loop detected in the linked list." << endl;
    } 
    else
    {
        cout << "No loop found in the linked list." << endl;
    }
    return 0;
}