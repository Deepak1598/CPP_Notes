#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

class BankAccount {
protected:
    int accountNumber;
    string name;
    double balance;
    vector<string> transactions;

public:
    BankAccount(int accNo = 0, string n = "", double bal = 0) {
        accountNumber = accNo;
        name = n;
        balance = bal;
    }

    virtual void deposit(double amount) {
        balance += amount;
        transactions.push_back("Deposited: " + to_string(amount));
        cout << "Deposit successful\n";
    }

    virtual void withdraw(double amount) {
        if (amount <= balance) {
            balance -= amount;
            transactions.push_back("Withdrawn: " + to_string(amount));
            cout << "Withdrawal successful\n";
        } else {
            cout << "Insufficient balance!\n";
        }
    }

    void displayBalance() {
        cout << "Balance: " << balance << endl;
    }

    void showTransactions() {
        cout << "\nTransaction History:\n";
        for (auto &t : transactions)
            cout << t << endl;
    }

    int getAccountNumber() { return accountNumber; }

    virtual string getType() = 0;

    virtual void saveToFile(ofstream &out) {
        out << getType() << endl;
        out << accountNumber << endl;
        out << name << endl;
        out << balance << endl;
        out << transactions.size() << endl;
        for (auto &t : transactions)
            out << t << endl;
    }

    virtual void loadFromFile(ifstream &in) {
        int tSize;
        in >> accountNumber;
        in.ignore();
        getline(in, name);
        in >> balance;
        in >> tSize;
        in.ignore();

        transactions.clear();
        for (int i = 0; i < tSize; i++) {
            string t;
            getline(in, t);
            transactions.push_back(t);
        }
    }
};

class SavingsAccount : public BankAccount {
public:
    using BankAccount::BankAccount;

    string getType() override {
        return "Savings";
    }
};

class CurrentAccount : public BankAccount {
public:
    using BankAccount::BankAccount;

    string getType() override {
        return "Current";
    }
};

// GLOBAL ACCOUNT LIST
vector<BankAccount*> accounts;

// Find account
BankAccount* findAccount(int accNo) {
    for (auto acc : accounts) {
        if (acc->getAccountNumber() == accNo)
            return acc;
    }
    return nullptr;
}

// Save all accounts
void saveAccounts() {
    ofstream out("accounts.txt");
    out << accounts.size() << endl;

    for (auto acc : accounts) {
        acc->saveToFile(out);
    }

    out.close();
    cout << "Accounts saved successfully!\n";
}

// Load accounts
void loadAccounts() {
    ifstream in("accounts.txt");

    if (!in) return;

    int size;
    in >> size;

    for (int i = 0; i < size; i++) {
        string type;
        in >> type;

        BankAccount *acc;

        if (type == "Savings")
            acc = new SavingsAccount();
        else
            acc = new CurrentAccount();

        acc->loadFromFile(in);
        accounts.push_back(acc);
    }

    in.close();
}

// Main Menu
int main() {
    loadAccounts();
    int choice;

    do {
        cout << "\n===== BANK SYSTEM =====\n";
        cout << "1. Create Account\n";
        cout << "2. Deposit\n";
        cout << "3. Withdraw\n";
        cout << "4. Check Balance\n";
        cout << "5. Transaction History\n";
        cout << "6. Save & Exit\n";
        cout << "Enter choice: ";
        cin >> choice;

        if (choice == 1) {
            int accNo;
            string name;
            double bal;
            int type;

            cout << "Enter Account Number: ";
            cin >> accNo;
            cin.ignore();

            cout << "Enter Name: ";
            getline(cin, name);

            cout << "Enter Initial Balance: ";
            cin >> bal;

            cout << "1. Savings  2. Current: ";
            cin >> type;

            BankAccount *acc;

            if (type == 1)
                acc = new SavingsAccount(accNo, name, bal);
            else
                acc = new CurrentAccount(accNo, name, bal);

            accounts.push_back(acc);

            cout << "Account created successfully!\n";
        }

        else if (choice == 2) {
            int accNo;
            double amt;
            cout << "Enter Account Number: ";
            cin >> accNo;

            BankAccount *acc = findAccount(accNo);
            if (acc) {
                cout << "Enter amount: ";
                cin >> amt;
                acc->deposit(amt);
            } else {
                cout << "Account not found!\n";
            }
        }

        else if (choice == 3) {
            int accNo;
            double amt;
            cout << "Enter Account Number: ";
            cin >> accNo;

            BankAccount *acc = findAccount(accNo);
            if (acc) {
                cout << "Enter amount: ";
                cin >> amt;
                acc->withdraw(amt);
            } else {
                cout << "Account not found!\n";
            }
        }

        else if (choice == 4) {
            int accNo;
            cout << "Enter Account Number: ";
            cin >> accNo;

            BankAccount *acc = findAccount(accNo);
            if (acc)
                acc->displayBalance();
            else
                cout << "Account not found!\n";
        }

        else if (choice == 5) {
            int accNo;
            cout << "Enter Account Number: ";
            cin >> accNo;

            BankAccount *acc = findAccount(accNo);
            if (acc)
                acc->showTransactions();
            else
                cout << "Account not found!\n";
        }

        else if (choice == 6) {
            saveAccounts();
            cout << "Exiting...\n";
        }

    } while (choice != 6);

    return 0;
}