#include <iostream>
using namespace std;

int main() {
    int* ptr = new int[10];  // Memory allocated

    // Some operations...
    
    return 0;  // ❌ Memory not freed → memory leak
}





====================================================================
#include <iostream>
using namespace std;

int main() {
    int* ptr = new int[10];  // Memory allocated

    // Some operations...

    delete[] ptr;
    
    return 0;  // ❌ Memory not freed → memory leak
}



