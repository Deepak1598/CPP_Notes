#include<iosrtream>
using namespace std;


namespace abc
{
    int x=10;
}
namespace xyz
{
    int x=100;
}

int main()
{
    cout<<xyz::x;

    return 0;
}