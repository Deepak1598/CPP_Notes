#include<iostream>
using namespace std;

class Node
{
    public:
        int data;
        Node* next;

        Node(int data)
        {
            this->data=data;
            this->next=NULL;
        }
        ~Node()
        {
            delete next;
        }

};

Node* reversList(Node* head)
{
    if(head==NULL || head->next==NULL)
    {
        return head;
    }

    Node* newHead = reversList(head->next);
    head->next->next=head;
    head->next=NULL;

    return newHead;
}

void PrintLink(Node* &head)
{
    if(head==NULL)
    {
        cout<<"link list is empty"<<endl;
    }
    Node *temp = head;
    while (temp != NULL)
    {
        cout<<temp->data<<" ";
        temp=temp->next;
    }
    
}

int main()
{
    Node * head = new Node(10);
    head->next = new Node(20);
    head->next->next = new Node(30);
    head->next->next->next = new Node(40);

    cout<<"origenal list is :"<<endl;
    PrintLink(head);

    cout<<endl;
    cout<<"revers list is : "<<endl;
    head=reversList(head);
    PrintLink(head);

    return 0;
}