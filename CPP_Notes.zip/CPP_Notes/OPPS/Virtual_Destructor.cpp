#include<iostream>
using namespace std;

class Animal
{
    public:
        Animal()
        {
            cout<<"Animal cunstructor is called"<<endl;
        }
       virtual ~Animal()
        {
             cout<<"Animal Destructor is called"<<endl;
        }
};

class Dog:public Animal
{
    public:
        Dog()
        {
            cout<<"Dog cunstructor is called"<<endl;
        }
        ~Dog()
        {
             cout<<"Dog Destructor is called"<<endl;
        }
};

int main()
{
    Dog *d=new Dog;
    Animal *a=d;
    
    delete a;
    
    return 0;
}









