#include<iostream>
using namespace std;

class Emp 
{
    private:
        string name;
        int age;
        int *sal;
        
    public:
        //Emp(){}
        Emp(string s,int a,int salry)
        {
            name=s;
            age=a;
            sal=new int;
            *sal=salry;
            
        }
        
        Emp(Emp &c)
        {
            name=c.name;
            age=c.age;
            sal=new int;
            *sal=*(c.sal);
        }
        void print()
        {
            cout<<"Name :"<<name<<endl;
            cout<<"Age :"<<age<<endl;
            cout<<"salery :"<<*sal<<endl;
        }
};

int main()
{
    Emp obj("Raj",25,1000);
    Emp obj2(obj);
    obj2.print();
    return 0;
}