#include<iostream>
using namespace std;
class A //Base class
{
    private:
        int x;
    public:
        A(int a)//class A cunstructer
        {
            x=a;
            cout<<"value of X :"<<x<<endl;
        }
};
class B :public A//Derive class 
{
    private:
        int y;
    public:
        B(int b,int a):A(a)//first called class A cunstructer then called Class B cunstructer !!
        {
           y=b; 
           cout<<"value of Y :"<<y<<endl;
        }
};

int main()
{
    B obj(5,10);
    
    return 0;
}