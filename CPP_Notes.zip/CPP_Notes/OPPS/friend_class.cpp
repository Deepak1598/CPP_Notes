#include<iostream>
using namespace std;


class Rohan
{
    private:
        int acc;
        int atm_pin;
        
    public:
        Rohan()
        {
            acc=100;
            atm_pin=1598;
        }
        friend class Deepak;
};
class Deepak
{
    public:
        void print(Rohan &o)
        {
            cout<<"acc balance is: "<<o.acc<<endl;
            cout<<"ATM pin is: "<<o.atm_pin<<endl;
            
        }
};


int main()
{
    Rohan obj;
    Deepak obj2;
    
    obj2.print(obj);
    
    return 0;
}