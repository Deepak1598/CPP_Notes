/*
A friend function is a non-member function that is declared with the friend keyword inside a class. 
Although it is not a member of the class, it can access 
the class's private and protected members. It is commonly used when a function needs access to 
private data of one or more classes,
*/

#include<iostream>
using namespace std;


class Rohan
{
    private:
        int acc;

    public:
        Rohan()
        {
            acc=1000;
        }   

        friend void print(Rohan &o); 
};
void print(Rohan &o)
{
    cout<<"Rohan Account Bal is :"<<o.acc<<endl;
}


int main()
{
    Rohan obj;
    print(obj);

    return 0;
}