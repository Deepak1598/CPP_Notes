#include<iostream>
using namespace std;

class Complex 
{
    private:
        int rel;
        int img;

    public:
        Complex(){}
        Complex(int r,int i)
        {
            rel=r;
            img=i;
        }

        Complex operator+(Complex &c)
        {
            Complex temp;
            temp.rel=rel+c.rel;
            temp.img=img+c.img;
            return temp;
        } 
        
        void print()
        {
            cout<<rel<<"+"<<img<<"i"<<endl;
        } 
};

int main()
{
    Complex c1(5,10),c2(10,5);
    Complex c3=c1+c2;
    c3.print();
    return 0;
}