#include <iostream>
using namespace std;

int divide(int n, int d) {
    if (d == 0) {
        throw "Division by zero is not allowed.";
    }
    return n / d;
}

int main() {
    int n, d;
    cout << "Enter numerator: ";
    cin >> n;
    cout << "Enter denominator: ";
    cin >> d;

    try {
        int result = divide(n, d);
        cout << "Result of division: " << result << endl;
    }
    catch (const char* errorMessage) {
        cout << "Error: " << errorMessage << endl;
    }

    return 0;
}
