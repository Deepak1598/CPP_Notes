#include<iostream>
#include<memory>
using namespace std;

void fun()
{
   unique_ptr<int>p1(new int(10));
   unique_ptr<int>p2;
   
   cout<<*p1<<endl;;
   p2=move(p1);
    if(p1==nullptr)
        cout<<"p1 is not an owner"<<endl;
    else
        cout<<*p1;
        
    cout<<*p2;    
}

int main()
{
    fun();
    
    cout<<endl;
    return 0;
}