#include<iostream>
using namespace std;

class Base
{                                                                       A
    public:
        virtual void print()                     
        {
            cout<<"print Base class"<<endl;
        }
        void show()
        {
            cout<<"show base class"<<endl;
        }
};
class Derive1 : public Base
{
    public:
         
        void show()
        {
            cout<<"show Derive1 class"<<endl;
        }
};


class Derive2 : public Base
{
    public:
        
        void show()
        {
            cout<<"show Derive2 class"<<endl;
        }
};

class Derive3 : public Derive1 ,public Derive2
{
    public:
        
        void show()
        {
            cout<<"show Derive class"<<endl;
        }
};


int main()
{
    Base *b;
    Derive3 d;
    b=&d;
    b->print();
    b->show();
    
    return 0;
}