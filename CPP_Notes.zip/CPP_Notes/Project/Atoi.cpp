
#include <stdio.h>

int Atoi(char str[])
{
    int i=0;
    int sing=1;
    int res=0;
    
    if(str[0]=='-')
    {
        sing=-1;
        i++;
    }
    for(;str[i]!='\0';i++)
    {
        res=res*10+str[i]-'0';
    }
    
    return sing*res;
    
}


int main()
{
    char str[]="-12345";
    
    int c=Atoi(str);
    
    printf("%d",c);

    return 0;
}
