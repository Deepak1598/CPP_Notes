#include <iostream>
#include <vector>

/* Observer Pattern defines a one-to-many 
relationship between objects so that when one object changes its state, 
all dependent objects are automatically notified.  */



using namespace std;

class Observer
{
public:
    virtual void update(string msg) = 0;
};

class Client : public Observer
{
    string name;

public:
    Client(string n) : name(n) {}

    void update(string msg)
    {
        cout << name << " received: "
             << msg << endl;
    }
};

class Server
{
    vector<Observer*> clients;

public:
    void subscribe(Observer* client)
    {
        clients.push_back(client);
    }

    void notifyAll(string msg)
    {
        for(auto client : clients)
        {
            client->update(msg);
        }
    }
};

int main()
{
    Server server;

    Client c1("Rahul");
    Client c2("Deepak");

    server.subscribe(&c1);
    server.subscribe(&c2);

    server.notifyAll("Hello Everyone");
}


