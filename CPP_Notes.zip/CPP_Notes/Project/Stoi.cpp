#include <iostream>
using namespace std;

int main() {
    string s = "5678";
    int num = stoi(s);
    cout << num << endl;
}