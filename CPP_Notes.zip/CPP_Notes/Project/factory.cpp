/*
Factory Design Pattern is a Creational Design Pattern that provides a centralized way to create objects. 
Instead of creating objects directly using the new keyword, the client requests the Factory class 
to create and return the required object. This hides the object creation logic from the client and promotes loose coupling.

*/
#include <iostream>
#include <string>

using namespace std;

// Abstract Base Class
class Animal
{
public:
    virtual void speak() = 0;

    virtual ~Animal() {}
};

// Concrete Class 1
class Dog : public Animal
{
public:
    void speak() override
    {
        cout << "Dog is Barking" << endl;
    }
};

// Concrete Class 2
class Cat : public Animal
{
public:
    void speak() override
    {
        cout << "Cat is Meowing" << endl;
    }
};

// Concrete Class 3
class Lion : public Animal
{
public:
    void speak() override
    {
        cout << "Lion is Roaring" << endl;
    }
};

// Factory Class
class AnimalFactory
{
public:
    static Animal* createAnimal(const string& type)
    {
        if (type == "Dog")
        {
            return new Dog();
        }
        else if (type == "Cat")
        {
            return new Cat();
        }
        else if (type == "Lion")
        {
            return new Lion();
        }

        return nullptr;
    }
};

int main()
{
    string animalType;

    cout << "Enter Animal Type (Dog/Cat/Lion): ";
    cin >> animalType;

    Animal* animal = AnimalFactory::createAnimal(animalType);

    if (animal != nullptr)
    {
        animal->speak();
        delete animal;
    }
    else
    {
        cout << "Invalid Animal Type!" << endl;
    }

    return 0;
}