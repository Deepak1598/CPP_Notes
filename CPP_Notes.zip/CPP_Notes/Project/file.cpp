#include<fstream>
#include<iostream>
using namespace std;

int main()
{
    ofstream fout("deepak.txt");
    //fout.open("deepak.txt");

    fout<<"hello Deepak I am king";

    /*ifstream fin;
    char ch;
    fin.open("deepak.txt");
    ch=fin.get();
    while(!fin.eof())
    {
        cout<<ch;
        ch=fin.get();
    }
    fin.close();*/

    return 0;
}