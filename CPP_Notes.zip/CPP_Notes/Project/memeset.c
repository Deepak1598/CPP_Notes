#include<stdlib.h>
#include<stdio.h>
#include<string.h>

int main()
{
    char str[10];

    memset(str,'a',8*sizeof(str[0]));
    //str[8]='\0';

    printf("%s",str);

    return 0;
}