// C++ program to demonstrate segmentation fault
// by Accessing an address that is freed
#include <iostream>
using namespace std;

int main(void)
{
	int *i=NULL;
    *i=10;
    cout<<*i<<endl;

	return 0;
}
