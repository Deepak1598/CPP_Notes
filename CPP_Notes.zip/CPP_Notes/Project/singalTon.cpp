#include <iostream>
using namespace std;

class Logger
{
private:
    // 1. Private Constructor
    Logger()
    {
        cout << "Logger Object Created\n";
    }

public:
    // 2. Static Function
    static Logger& getInstance()
    {
        // 3. Static Local Object
        static Logger instance;

        return instance;
    }

    void log(string msg)
    {
        cout << "LOG : " << msg << endl;
    }
};

int main()
{
    Logger& log1 = Logger::getInstance();
    Logger& log2 = Logger::getInstance();

    log1.log("Login Success");
    log2.log("Patient Added");

    cout << &log1 << endl;
    cout << &log2 << endl;

    return 0;
}