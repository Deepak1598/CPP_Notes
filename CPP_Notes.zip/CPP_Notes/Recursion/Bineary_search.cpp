#include<iostream>
using namespace std;

void print(int arr[],int s,int e)
{
    for(int i=s;i<=e;i++)
    {
        cout<<arr[i]<<" ";
    }
    cout<<endl;
}

bool BinerySearch(int arr[],int s,int e,int k)
{
    print(arr,s,e);
    if(s>e)
    {
        return false;
    }
    int m=(s+e)/2;
    if(arr[m]==k)
    {
        return true;
    }
    if(arr[m]<k)
    {
        return BinerySearch(arr,m+1,e,k);
    }
    else
    {
        return BinerySearch(arr,s,m-1,k);
    }
}

int main()
{
    int arr[]={2,4,6,8,11,13,14,15,16};
    int n=sizeof(arr)/sizeof(arr[0]);
    int k=1;
    int s=0;
    //int e=n-1;
    
   bool ans= BinerySearch(arr,s,n-1,k);
   
   if(ans)
   {
       cout<<"Yes"<<endl;
   }
   else
   {
       cout<<"NO"<<endl;
   }
    return 0;
}