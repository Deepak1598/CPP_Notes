#include <iostream>
#include<cmath>
using namespace std;


void BinerytoDecimal(string binery)
{
    int decimal=0;
    int n=binery.size();
    for(int i=0;i<n;i++)
    {
        if(binery[i]=='1')
        {
            decimal=decimal+pow(2,n-1-i);
            
        }
    }
    cout<<decimal;
}


int main()
{
    string binery="1001";
    
    BinerytoDecimal(binery);
    
    return 0;
}