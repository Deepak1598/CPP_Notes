#include <iostream>
#include<vector>
using namespace std;

void decimalToBinery(int n)
{
    vector<int>v;
    while(n>0)
    {
        int d=n%2;
        v.push_back(d);
        n=n/2;
    }
    for(int i=v.size()-1 ;i>=0 ;i--)
    {
        cout<<v[i];
    }
}


int main()
{
    int n=10;
    
    decimalToBinery(n);
    return 0;
}