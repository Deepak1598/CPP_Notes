#include<iostream>
using namespace std;

void home(int src,int desc)
{
    if(src==desc)
    {
        cout<<"ghar aa gaya"<<endl;
        return;
    }
    src++;
    cout<<"source : "<<src<<"  "<<"Destination : "<<desc<<endl;
    home(src,desc);
    
}
    

int main()
{
    int src=0;
    int desc=10;
    
    home(src,desc);
    
    return 0;
}