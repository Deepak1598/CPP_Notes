#include<iostream>
using namespace std;

void print(int arr[],int n)
{
    for(int i=0;i<n;i++)
    {
        cout<<arr[i]<<" ";
    }
    
}
int partion(int arr[],int s,int e)
{
    int pivot=arr[s];
    
    int count=0;
    for(int i=s+1;i<=e;i++)
    {
        if(arr[i]<=pivot)
        {
            count++;
        }
    }
    //right place;
    int pivotIndex=s+count;
    swap(arr[s],arr[pivotIndex]);
    
    //left and right part 
    int i=s,j=e;
    while(i<pivotIndex && j>pivotIndex)
    {
        while(arr[i]<pivot)
        {
            i++;
        }
        while(arr[j]>pivot)
        {
            j--;
        }
        
        if(i<pivotIndex && j>pivotIndex)
        {
            swap(arr[i++],arr[j--]);
        }
    }
    return pivotIndex;
    
}

void quickShort(int arr[],int s,int e)
{
    if(s>=e)
    {
        return;
    }
    int p=partion(arr,s,e);
    
    quickShort(arr,s,p-1);
    quickShort(arr,p+1,e);
    
}


int main()
{
    int arr[]={2,1,34,8,21};
    int n=sizeof(arr)/sizeof(arr[0]);
    int s=0;
    
    quickShort(arr,s,n-1);
    print(arr,n);
    
    return 0;
}