#include<iostream>
using namespace std;


void revers(string &str,int s,int e)
{
    if(s>e)
    {
        return ;
    }
    swap(str[s],str[e]);
    s++;
    e--;
    
     revers(str,s,e);
}


int main()
{
    string str="deepak";
    
    int n=str.size();
    
    revers(str,0,n-1);
    
    cout<<str<<endl;
    
    return 0;
}