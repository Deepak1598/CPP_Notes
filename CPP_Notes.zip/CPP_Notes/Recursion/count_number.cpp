#include<iostream>
using namespace std;

void print(int n)
{
    if(n==0)//base condition
    {
        return;
    }
    
    //cout<<n<<endl;//head recursion
    print(n-1);//RR
    cout<<n<<endl;//tail recursion  
}


int main()
{
    int n;
    cin>>n;             
    
    print(n);
    
    return 0;
}