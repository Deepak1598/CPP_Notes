#include<iostream>
using namespace std;

int fibo(int n)
{
    if(n==0 || n==1)
    {
        return n;
    }
    
    return fibo(n-1)+fibo(n-2);
}
    

int main()
{
    int n=5;
    int i=0;
    while(n>i)
    {
        cout<<fibo(i)<<endl;
        i++;
    }
   
    return 0;
}