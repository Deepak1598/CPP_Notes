#include<iostream>
using namespace std;

void mergeTwoArray(int arr1[],int arr2[],int m,int n)
{
    //int x=m+n;
    int arr[m+n];
    int i=0,j=0;
    int mainIndex=0;
    while(i<m && j<n)
    {
        if(arr1[i]<arr2[j])
        {
            arr[mainIndex++]=arr1[i++];
        }
        else
        {
            arr[mainIndex++]=arr2[j++];
        }
        
    }
    while(i<m)
    {
        arr[mainIndex++]=arr1[i++];
    }
    while(j<n)
    {
        arr[mainIndex++]=arr2[j++];
    }
    
    for(int i=0;i<(m+n);i++)
    {
        cout<<arr[i]<<" ";
    }
    
}


int main()
{
    int arr1[]={1,3,5,7,9};
    int arr2[]={2,4,6,8};
    
    int m=sizeof(arr1)/sizeof(arr1[0]);
    int n=sizeof(arr2)/sizeof(arr2[0]);
    
    mergeTwoArray(arr1,arr2,m,n);
    
    return 0;
    
}