#include<iostream>
using  namespace std;
void print(int n,string arr[])
{
    if(n==0)
    {
        return;
    }
    int d=n%10;
    n=n/10;
    print(n,arr);
    cout<<arr[d]<<" ";
}

int main()
{
    int n=1234;

    string arr[10]={ "zero","one","two","three","four","five","six","seven","Eight","nine"};

    cout<<endl<<endl<<endl;
    print(n,arr);
    cout<<endl<<endl<<endl;

    return 0;
}