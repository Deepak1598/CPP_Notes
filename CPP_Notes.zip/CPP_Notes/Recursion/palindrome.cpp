#include<iostream>
using namespace std;


bool palindrom(string str,int s,int e)
{
    if(s>e)
    {
        return true;
    }
    if(str[s]!=str[e])
    {
        return false;
    }
    else
    {
        return palindrom(str,s+1,e-1);
    }
}


int main()
{
    string str="noon";
    
    int n=str.size();
    
   bool ans= palindrom(str,0,n-1);
    
    if(ans)
    {
        cout<<"yes"<<endl;
    }
    else
    {
        cout<<"NO"<<endl;
    }
    
    
    
    return 0;
}