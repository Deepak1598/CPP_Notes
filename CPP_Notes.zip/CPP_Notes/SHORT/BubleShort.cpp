#include<iostream>  //Bubbble sort//
using namespace std;//In a first round sort the last position pacle the largest element.

void bubulShort(int arr[],int n)
{
    for(int i=0;i<n-1;i++)
    {
        bool value=false;
        for(int j=0;j<n-i-1;j++)
        {       
            if(arr[j]>arr[j+1])
            {
                swap(arr[j],arr[j+1]);
                value=true;
            }
          
        }
         if(value==false)//Pahle se hi short hai Array!!
            {
                 break;
            }
        
    }
}
void printArray(int arr[],int n){
    for(int i=0;i<n;i++)
    {
        cout<<arr[i]<<" ";
    }
}

int main()
{
    int arr[]={4,3,5,25,70,99,98};
    int n=sizeof(arr)/sizeof(arr[0]);
    
    bubulShort(arr,n);
    cout<<"Shorted array is here:";
    printArray(arr,n);
    
    return 0;
}