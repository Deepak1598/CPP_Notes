#include<iostream>//In first itration small element place on right position.
using namespace std;

void InsertionShort(int arr[],int n)
{
    for (int i = 1; i < n; i++) 
    {
        int key = arr[i];
        int j = i - 1;

        
        while (j >= 0 && arr[j] > key)
        {
            arr[j + 1] = arr[j];
            j = j - 1;
        }
        arr[j + 1] = key;
    }
}

void printArray(int arr[],int n)
{
    for(int i=0;i<n;i++)
    {
        cout<<arr[i]<<" ";
    }
}

int main()
{
    int arr[]={4,3,5,25,70};
    int n=sizeof(arr)/sizeof(arr[0]);
    //cout<<"value of n:"<<n;
    
    InsertionShort(arr,n);
    cout<<"Shorted array is here:";
    printArray(arr,n);
    
    return 0;
}




