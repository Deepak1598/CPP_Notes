#include<iostream>
using namespace std;

//Selection Sort repeatedly finds the minimum from the unsorted part and swaps it into its correct position
void selection(int arr[],int n)
{
    for(int i=0;i<n;i++)
    {
        int minIndex=i;
        for(int j=i+1;j<n;j++)
        {
            if(arr[j]<arr[minIndex])
            {
                minIndex=j;
            }
            
        }
        swap(arr[minIndex],arr[i]);
    }
    //return 0;
}

void printArray(int arr[],int n)
{
    for(int i=0;i<n;i++)
    {
        cout<<arr[i]<<" ";
    }
}

int main(){
    
    int arr[6]={6,3,5,8,23,2};
    cout<<"selection short is:";
    selection(arr,6);
    printArray(arr,6);
    
    return 0;
}