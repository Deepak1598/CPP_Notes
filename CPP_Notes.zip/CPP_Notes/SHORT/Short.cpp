#include<iostream>
using namespace std;

int main()
{
    int arr[7]={5,2,4,3,9,7,1};

    int arr2[7]=short(arr.begin(),arr.end());

    for(int i=0;i<7;i++)
    {
        cout<<arr2[i]<<" ";
    }

    return 0;
}