#include<iostream>
#include<map>
using namespace std;

int main()
{
   
   string str="deepakaa";
   
   map<char,int>m;
   int maxf=0;
   for(int i=0;i<str.size();i++)
   {
       m[str[i]]++;
       maxf=max(maxf,m[str[i]]);
   }
   
   for(auto i:m)
   {
       if(maxf==i.second)
        {
            cout<<i.first<<" "<<i.second<<endl;
         }
   }
    
    return 0;
}