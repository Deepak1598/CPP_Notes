#include <iostream>
using namespace std;

int min(int x, int y) 
{ 
return (x < y) ? x : y; 
}

int utility_fun_for_del(string str, int i, int j)
{
	if (i >= j)
		return 0;

	if (str[i] == str[j]) 
	{
		return utility_fun_for_del(str,i + 1, j - 1);
	}
	return 1 + min(utility_fun_for_del(str, i + 1, j),utility_fun_for_del(str, i, j - 1));
}

int min_ele_del(string str)
{
	return utility_fun_for_del(str, 0,str.length() - 1);
}

int main()
{
	string str = "abefbac";
	cout << "Minimum element of deletions = "
		<< min_ele_del(str) << endl;
	return 0;
}

