#include <iostream>
#include <vector>
using namespace std;

bool find(string word,string str2)
{
    int m=word.size();
    int n=str2.size();

    int j=0;
    for(int i=0;i<n && j<m;i++)
    {
        if(word[j]==str2[i])
        {
            j++;
        }
    }

    return (j==m);
}


string findMaxString(vector<string> dict,string str)
{
    int len=0;
    string res="";

    for(string word:dict)
    {
        if(len<word.size() && find(word,str))
        {
            //cout<<"hello";
            res=word;
            len=word.size();
        }
    }
    //cout<<res<<endl;
    return res;
}


int main()
{
    vector<string> dict = {"ale", "apple", "monkey", "plea"} ;  
    string  str = "abpcplea";
    cout<<findMaxString(dict,str);

    return 0;
}