#include<iostream>  
#include<map>
#include<vector>
using namespace std;

void coutnMax(string str,int n)
{
    vector<string>v;
    string s="";
    for(int i=0;i<n;i++)
    {
        if(str[i]==' ')
        {
           v.push_back(s);
           s="";
        }
        else
        {
            s=s+str[i];
        }
    }
    v.push_back(s);
    
    map<string,int>m;
    int maxf=0;
    for(int i=0;i<v.size();i++)
    {
        m[v[i]]++;
        maxf=max(maxf,m[v[i]]);
    }
    int c;
    for(auto i:m)
    {
        if(maxf==i.second)
            cout<<i.first<<" "<<i.second<<endl;
    }
}


int main()
{
    string str="hello deepak i am deepak you are also deepak";
    
    int n=str.size();
    
    coutnMax(str,n);
    
    return 0;
}
