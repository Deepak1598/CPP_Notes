#include<string>
#include <iostream>
using namespace std;

void reverse(string str,int n)
{
    int s=0,e=n-1;
    while(s<e)
    {
        swap(str[s],str[e]);
        s++;
        e--;
    }
    cout<<str<<endl;
}
int main()
{
    string str="abcde";
    
    int n=str.size();
    
    reverse(str,n);

    return 0;
}
