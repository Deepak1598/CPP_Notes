#include<string>
#include <iostream>
using namespace std;

void checkPalindrome(string str,int n)
{
    string temp=str;
    int s=0,e=n-1;
    while(s<e)
    {
        swap(str[s],str[e]);
        s++;
        e--;
    }

    if(temp==str)
    {
        cout<<"YES...!";
    }
    else
    {
        cout<<"NO....!";
    }
    
}
int main()
{
    string str="abcdcba";
    
    int n=str.size();
    
    checkPalindrome(str,n);

    return 0;
}
