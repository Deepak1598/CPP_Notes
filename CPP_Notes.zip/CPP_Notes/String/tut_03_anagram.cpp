#include <iostream>
using namespace std;

bool isAnagram(string str1, string str2)
{
    if(str1.length() != str2.length())
        return false;

    int freq[256] = {0};

    for(char ch : str1)
        freq[ch]++;

    for(char ch : str2)
        freq[ch]--;

    for(int i = 0; i < 256; i++)
    {
        if(freq[i] != 0)
            return false;
    }

    return true;
}

int main()
{
    string str1 = "listen";
    string str2 = "silent";

    cout << (isAnagram(str1, str2) ? "YES" : "NO");
}