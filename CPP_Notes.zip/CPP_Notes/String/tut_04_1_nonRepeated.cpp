#include<iostream>
#include<map>
using namespace std;

void nonRepeated(string str,int n)
{
    map<char,int>m;
    
    for(int i=0;i<n;i++)
    {
        m[str[i]]++;
    }
    for(auto i:m)
    {
       if(i.second==2)
       {
           cout<<i.first<<"  "<<i.second<<endl;
       }
    }
}

int main()
{
    string str="deepak";

    int n=str.size();

    nonRepeated(str,n);

    return 0;
}