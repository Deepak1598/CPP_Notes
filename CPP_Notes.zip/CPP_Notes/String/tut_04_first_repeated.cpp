#include<iostream>
using namespace std;

void nonRepeated(string str,int n)
{
    for(int i=0;i<n;i++)
    {
        for(int j=i+1;j<n;j++)
        {
            if(str[i]==str[j])
            {
                cout<<str[i]<<endl;
                break;
            }
        }
    }
    //cout<<"NOOOO........!!!";
}

int main()
{
    string str="deepak";

    int n=str.size();

    nonRepeated(str,n);

    return 0;
}