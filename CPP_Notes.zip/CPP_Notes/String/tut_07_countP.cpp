#include<iostream>
using namespace std;

int countSub(string s)
{
    int n=s.size();
    if(n==0||n==1)
    {
        return n;
    }
    
    int count =0;
    for(int i=0;i<n;i++)
    {
        int j=i;
        int k=i;//odd
        //cout<<"odd"<<endl;
        while( j>=0 && k<n && s[j]==s[k] )
        {
            j--;
            k++;
            //cout<<s[j]<<" ";
            count++;
        }
        
        j=i;
        k=i+1;//even
        //cout<<"EVEN"<<endl;
        while( j>=0 && k<n && s[j]==s[k] )
        {
            j--;
            k++;
           // cout<<s[j]<<" ";
            count++;
        }
        
    }
    return (count-n);
}



int main()
{
    string s="bcbabab";
    
    cout<<countSub(s);
    return 0;
}