#include<iostream>
#include<vector>
using namespace std;

void revesrseString(string s,int n)
{
    vector<string>temp;
    string str="";

    for(int i=0;i<n;i++)
    {
        if(s[i]==' ')
        {
            temp.push_back(str);
            str="";
        }
        else
        {
            str=str+s[i];
        }

        
    }
    temp.push_back(str);

    for(int i=temp.size()-1;i>0;i--)
    {
        cout<<temp[i]<<" ";
    }
    cout<<temp[0];
}

int main()
{
    string s="Hello I am deepak Yadav";

    int n=s.size();

    revesrseString(s,n);

    return 0;
}