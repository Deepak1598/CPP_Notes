#include <iostream>
#include <thread>
#include <semaphore>
using namespace std;

counting_semaphore<int> sem(1); // Initialize a semaphore with an initial count of 1

void increment_counter() {
    sem.acquire(); // Wait until the semaphore count is greater than zero
    // Critical section: shared resource access
    cout << "Incrementing counter..." << endl;
    // Simulating some work
    this_thread::sleep_for(std::chrono::seconds(1));
    sem.release(); // Signal that the critical section is complete
}

int main() {
    thread t1(increment_counter);
    thread t2(increment_counter);

    t1.join();
    t2.join();

    return 0;
}
