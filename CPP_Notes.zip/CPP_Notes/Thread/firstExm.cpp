
#include <iostream>
#include<thread>
#include<algorithm>
#include <chrono>
using namespace std::chrono;
using namespace std;
typedef unsigned long long ull;

ull EvenSum=0;
ull OddSum=0;

void findEvenSum(int st,int end)
{
   // ull EvenSum=0;
    for(ull i=st;i<=end;++i)
    {
        
        if((i%2)==0)
        {
            //cout<<i<<endl;
            EvenSum+=i;
        }
    }
    //return EvenSum;
}

void findOddSum(int st,int end)
{
    //ull OddSum=0;
    for(ull i=st;i<=end;++i)
    {
        if((i%2)!=0)
        {
            //cout<<i<<endl;
            OddSum+=i;
        }
    }
   // return OddSum;
}

int main()
{
    ull st=1,end=1000000;
    
    auto start= high_resolution_clock::now();
    //creat the first thread
   thread t1(findOddSum,st,end);
    //second thread
    thread t2(findEvenSum,st,end);
    
    //join th thread
    t1.join();
    t2.join();
    
    
    
   // findOddSum(st,end);
    //cout<<"#################"<<endl;
    //findEvenSum(st,end);
    
   
    cout<<"sum of all odd number : "<<OddSum<<endl;
    cout<<"sum of all even number : "<<EvenSum<<endl;
    auto stop = high_resolution_clock::now();
    
    
    auto duration = duration_cast<microseconds>(stop-start);
    cout << duration.count()<<endl;
    

    return 0;
}
