#include <iostream>
#include <thread>
#include <chrono>
using namespace std;

void run(int count )
{
    while(count-- > 0)
    cout <<count<< "Deepak"<<endl;
    this_thread::sleep_for(chrono::seconds(3));
}

int main()
{
    thread t1(run,10);
    cout<<"Name"<<endl;
    //t1.join();
    t1.detach();
    cout<<" After Name"<<endl;
    
    return 0;
}