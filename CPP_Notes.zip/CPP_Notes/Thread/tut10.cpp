#include <iostream>       // std::cout
#include <chrono>         // std::chrono::milliseconds
#include <thread>         // std::thread
#include <mutex>          // std::timed_mutex

// for more tutorials on C, C++, DS visit www.ProDeveloperTutorial.com

using namespace std;

std::mutex mtx;

int count_num = 0;


void increment_fun (int thread_num, int val) 
{
   
    unique_lock<mutex> lock(mtx); // locking mtx mutex 

    for (int i = 0; i < val; ++i)
    {
        cout<<"Thread "<<thread_num<<" count = "<<count_num++<<endl;
    }
    //mtx.unlock();// no need to call unlock
}

int main ()
{
    std::thread t1 (increment_fun, 1, 5);
    std::thread t2 (increment_fun, 2, 6);
    
    t1.join();
    t2.join();
    

  return 0;
}