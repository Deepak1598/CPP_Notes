/*
In this example, we have two threads, thread1 and thread2, each attempting to acquire two mutexes (mutex1 and mutex2). 
They acquire these locks in different order, which leads to a deadlock scenario.

Here's what happens:

1)thread1 attempts to lock mutex1 and mutex2.
2)thread2 attempts to lock mutex2 and mutex1.
If thread1 acquires mutex1 and thread2 acquires mutex2 at the same time, a deadlock occurs. 
thread1 is waiting for mutex2 to be released by thread2, and thread2 is waiting for mutex1 to be released by thread1.

This program will not terminate and will be stuck in a deadlock. Deadlocks can be quite tricky to debug, 
so it's important to design your threading code in a way that avoids such situations.
*/
#include<iostream>
#include<thread>
#include<chrono>
#include<mutex>
using namespace std;

mutex m1;
mutex m2;

void TaskA()
{
    m1.lock();
    this_thread::sleep_for(std::chrono::seconds(1));//u can not use the sleep time than u can not show the dead lock condition
    m2.lock();
    cout<<"Task A is exicuted "<<endl;
    m1.unlock();
    m2.unlock();
}

void TaskB()
{
    m2.lock();
    this_thread::sleep_for(std::chrono::seconds(1));
    m1.lock();
    cout<<"Task B is exicuted"<<endl;
    m2.unlock();
    m1.unlock();
}



int main()
{
    thread t1(TaskA);
    thread t2(TaskB);

    t1.join();
    t2.join();

    return 0;

}