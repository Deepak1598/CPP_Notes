#include<iostream>
#include<thread>
#include<chrono>
#include<mutex>
using namespace std;

mutex m;

int BankBalance=0;

void addMoney(int value)
{
    m.lock();
    BankBalance+=value;
    m.unlock();
}

int main()
{
    thread t1(addMoney,100);
    thread t2(addMoney,200);

    t1.join();
    t2.join();

    cout<<"Bank Balance is :"<<BankBalance<<endl;

    return 0;
}