#include <iostream>       // std::cout
#include <chrono>         // std::chrono::milliseconds
#include <thread>         // std::thread
#include <mutex>          // std::timed_mutex
#include <condition_variable>          // std::condition_variable

using namespace std;

condition_variable cv;
mutex mtx;
int balance = 0;
void deposit(int money)
{
    lock_guard<mutex> lg(mtx);

    balance = balance + money;
    cout<<"The current balance is "<<balance<<endl;

    cv.notify_one();
}
void withdraw(int money)
{
    unique_lock <mutex> ul(mtx);

    cv.wait(ul, [] {
            return (balance != 0) ? true : false;
    });

   if ( balance >= money)
   {
        balance -= money;
        cout<<"The amount has been withdrawn"<<endl;
   }
   else
   {
        cout<<"The current balance is less than the amount"<<endl;
   }

        cout<<"The current balance is"<<balance<<endl;
}
int main ()
{
    thread t1 (withdraw, 400);
    thread t2 (deposit, 600);
    
    t1.join();
    t2.join();
  return 0;
}