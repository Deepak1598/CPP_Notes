#include <iostream>
#include <future>
#include<thread>
using namespace std;
void findOdd(promise<int>OddSumPromise ,int start,int end)
{
    int OddSum=0;
    for(int i=0;i<end;i++)
    {
        OddSum+=i;
    }
    OddSumPromise.set_value(OddSum);
}
int main()
{
    int start=0,end=100;

    promise<int> oddSum;
    future<int> OddFuture = oddSum.get_future();

    cout<<"Thread Created !!"<<endl;

    thread t1(findOdd,move(oddSum),start,end);

    cout<<"wating for result"<<endl;

    cout<<"OddSum "<<OddFuture.get()<<endl;
    cout<<"completed !!"<<endl;
    t1.join();
    return 0;
}