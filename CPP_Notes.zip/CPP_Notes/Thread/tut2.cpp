#include<iostream>
#include<thread>
using namespace std;

//1.function pointer
/*void fun(int x){
    while(x-- >0)
    {
        cout<<x<<endl;
    }
}
int main()
{
    thread t(fun,10);
    t.join();
    return 0;
}

*/


//2.lambda function
/*int main()
{
    thread t([](int x){while(x-- >0){cout<<x<<endl;}},10);
    
    t.join();
    return 0;
}*/


//3.functor
//4.Non static member function
class base
{
    public:
        void operator() (int x)
        {
            while(x-->0)
            {
                cout<<x<<endl;
            }
        }
};
int main()
{
    thread t((base()),10);
    t.join();
    return 0;
}
//4.Non static member function
/*class base
{
    public:
        void run(int x)
        {
            while(x-->0)
            {
                cout<<x<<endl;
            }
        }
};
int main()
{
    base b;
    thread t(&base::run,&b,10);
    t.join();
    return 0;
}
*/

//5.Static member function
class base
{
    public:
        static void run(int x)
        {
            while(x-->0)
            {
                cout<<x<<endl;
            }
        }
};
int main()
{
    //base b;
    thread t(&base::run,10);
    t.join();
    return 0;
}