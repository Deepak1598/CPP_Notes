#include<iostream>
#include<thread>
#include<chrono>
#include<mutex>
using namespace std;

mutex m;
int myamount=0;
void increment(){
    m.lock();
    ++myamount;
    m.unlock();
}



int main()
{
    thread t1(increment);
    thread t2(increment);

    t1.join();
    t2.join();

    cout<<"My money is :"<<myamount;
    return 0;
}