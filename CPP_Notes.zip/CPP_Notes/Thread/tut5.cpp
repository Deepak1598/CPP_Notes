#include<iostream>
#include<thread>
#include<chrono>
#include<mutex>
using namespace std;

int count=0;
mutex mtx;

void incremented1000Times()
{
    for(int i=0;i<100000;i++)
    {
        if(mtx.try_lock())
        {
            +count;
            mtx.unlock();
        }
    }
}

int main()
{
    thread t1(incremented1000Times);
    thread t2(incremented1000Times);

    t1.join();
    t2.join();

    cout<<"total count is :"<<count<<endl;

    return 0;
}