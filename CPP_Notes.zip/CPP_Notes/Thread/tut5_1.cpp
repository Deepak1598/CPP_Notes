#include <iostream>
#include <thread>
#include <mutex>
using namespace std;


mutex mtx;

void print_thread_id(int id) {
    while (true) {
        if (mtx.try_lock()) {
            cout << "Thread " << id << " is executing." << endl;
            mtx.unlock();
            break;
        } else {
            cout << "Thread " << id << " is waiting." << endl;
            this_thread::sleep_for(std::chrono::milliseconds(10000));
        }
    }
}

int main() {
    thread t1(print_thread_id, 1);
    thread t2(print_thread_id, 2);

    t1.join();
    t2.join();

    return 0;
}
