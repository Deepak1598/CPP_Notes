#include<iostream>
#include<thread>
#include<chrono>
#include<mutex>
using namespace std;


int myAcount=0;
timed_mutex m;

void increment(int i)
{
    if(m.try_lock_for(std::chrono::seconds(1)))
    {
        ++myAcount;
        this_thread::sleep_for (std::chrono::seconds(2));
        cout<<"thread "<<i<<" entered"<<endl;
        m.unlock();
    }
    else
    {
        cout<<"thread "<<i<<" coldnot enter"<<endl;
    }
}

int main()
{
    thread t1(increment,1);
    thread t2(increment,2);

    t1.join();
    t2.join();
    cout<<myAcount<<endl;
    return 0;
}