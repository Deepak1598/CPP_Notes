#include<iostream>
#include<thread>
#include<chrono>
#include<mutex>
using namespace std;

recursive_mutex m;
int buffer=0;

void recusion(char c,int loop)
{
    if(loop<0)
    {
        return;
    }

    m.lock();
    cout<<"locked by thread id : "<<c<<" is"<<++buffer<<endl;
    recusion(c,--loop);
    m.unlock();
    cout<<"unlocked by threadID:"<<c<<endl;


}
int main()
{
    thread t1(recusion,'1',2);
    thread t2(recusion,'2',2);

    t1.join();
    t2.join();
}