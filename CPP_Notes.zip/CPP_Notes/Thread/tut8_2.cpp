#include<iostream>
#include<thread>
#include<chrono>
#include<mutex>
using namespace std;

recursive_mutex m;

int main()
{
    for(int i=0;i<3;i++)
    {
        m.lock();
        cout<<"Value lock is :"<<i<<endl;
    }
     for(int i=0;i<3;i++)
    {
        m.unlock();
        cout<<"Value unlock is :"<<i<<endl;
    }
}