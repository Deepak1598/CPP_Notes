#include<iostream>
#include<thread>
#include<chrono>
#include<mutex>
using namespace std;

mutex m1;
int buffer=0;

void task(char c ,int value)
{
    lock_guard<mutex> lock(m1);
    for(int i=0;i<value;++i)
    {
        buffer++;
        cout<<"thread no."<< c <<" "<<buffer<<endl; 
    }

}

int main()
{
    thread t1(task,'1',5);
    thread t2(task,'2',5);

    t1.join();
   //cout<<"######";
    t2.join();
    return 0;
}